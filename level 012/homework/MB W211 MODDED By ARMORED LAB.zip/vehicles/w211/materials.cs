singleton Material(dvig)
{
   mapTo = "dvig";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/dvig.png";
   diffuseMap[1] = "vehicles/w211/TXT/dvig.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(rearbeam)
{
   mapTo = "rearbeam";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/fara.png";
   diffuseMap[1] = "vehicles/w211/TXT/fara.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(penisR)
{
   mapTo = "penisR";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/fara.png";
   diffuseMap[1] = "vehicles/w211/TXT/fara.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(reverse)
{
   mapTo = "reverse";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/fara.png";
   diffuseMap[1] = "vehicles/w211/TXT/fara.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(penisL)
{
   mapTo = "penisL";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/fara.png";
   diffuseMap[1] = "vehicles/w211/TXT/fara.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(dred)
{
   mapTo = "dred";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/dred.png";
   diffuseMap[1] = "vehicles/w211/TXT/dred.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(gm_engine)
{
   mapTo = "gm_engine";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/gm_engine.png";
   diffuseMap[1] = "vehicles/w211/TXT/gm_engine.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(dr1)
{
   mapTo = "dr1";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/dr1.png";
   diffuseMap[1] = "vehicles/w211/TXT/dr1.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(w211_comp)
{
   mapTo = "w211_comp";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/01 copy.png";
   diffuseMap[1] = "vehicles/w211/TXT/01 copy.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(tex_01)
{
   mapTo = "tex_01";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/tex_01.png";
   diffuseMap[1] = "vehicles/w211/TXT/tex_01.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(fara)
{
   mapTo = "fara";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/fara.png";
   diffuseMap[1] = "vehicles/w211/TXT/fara.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(ak47)
{
   mapTo = "ak47";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/w211/TXT/ak47.png";
   diffuseMap[1] = "vehicles/w211/TXT/ak47.png";
   materialTag0 = "Miscellaneous";
};

singleton Material(scfgeen)
{
    mapTo = "screen";
    diffuseMap[0] = "@gt63s_screen";
    reflectivityMap[0] = "vehicles/w211/BMWM5F10_screen_s.dds";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "global_cubemap_metalblum6ed";
    emissive[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(faraON)
{
   mapTo = "faraON";
   diffuseColor[0] = "1 1 1 0.1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "3";
   doubleSided = "1";
   translucentBlendOp = "None";
   ddiffuseMap[0] = "vehicles/w211/TXT/faraON.png";
   diffuseMap[1] = "vehicles/w211/TXT/faraON.png";
   glow[1] = "1";
   emissive[1] = "1";
   materialTag0 = "Miscellaneous";
};